#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArduinoLog.h"
#include "Fonctions.h"


#include "Mapping.h"

    Mapping::Mapping() {

      mapping[1] = (char*)"B4";
      mapping[2] = (char*)"L1";

      mapping[3] = (char*)"R5";
      mapping[4] = (char*)"N100";

      mapping[5] = (char*)"B6";
      mapping[6] = (char*)"L3";

      mapping[7] = (char*)"B7";
      mapping[8] = (char*)"L4";

      mapping[9] = (char*)"B8";
      mapping[10] = (char*)"L5";

      mapping[11] = (char*)"B9";
      mapping[12] = (char*)"L6";

      mapping[13] = (char*)"B*";
      mapping[14] = (char*)"LON";

      mapping[15] = (char*)"B0";
      mapping[16] = (char*)"L7";

      mapping[17] = (char*)"A1";
      mapping[18] = (char*)"F01";
      //mapping[18] = (char*)"L! LE+% |L! LE-% |L! LE-% ";

      mapping[19] = (char*)"A2";
      mapping[20] = (char*)"F02";

      mapping[21] = (char*)"RB";
      mapping[22] = (char*)"NN+";

      mapping[23] = (char*)"RC";
      mapping[24] = (char*)"NN-";

      mapping[25] = (char*)"A6";
      mapping[26] = (char*)"F08";

      mapping[27] = (char*)"B1";
      mapping[28] = (char*)"R1";

      mapping[29] = (char*)"B2";
      mapping[30] = (char*)"R2";

      mapping[31] = (char*)"LB";
      mapping[32] = (char*)"R2";
	  
	  mapping[33] = (char*)"A7";
      mapping[34] = (char*)"F09";

      mapping[35] = (char*)"LC";
      mapping[36] = (char*)"F02";

      mapping[37] = (char*)"A9";
      mapping[38] = (char*)"F11";

      mapping[39] = (char*)"LB";
      mapping[40] = (char*)"F01";

      mapping[41] = (char*)"LC";
      mapping[42] = (char*)"";

      mapping[43] = (char*)"L7";
      mapping[44] = (char*)"F09";

      mapping[45] = (char*)"L8";
      mapping[46] = (char*)"F08";

      mapping[47] = (char*)"LD";
      mapping[48] = (char*)"F07";

      mapping[49] = (char*)"L5";
      mapping[50] = (char*)"F12";

      mapping[51] = (char*)"LB";
      mapping[52] = (char*)"F01";

      mapping[53] = (char*)"R8";
      mapping[54] = (char*)"LON";

      mapping[55] = (char*)"R7";
      mapping[56] = (char*)"L1";

      mapping[57] = (char*)"R6";
      mapping[58] = (char*)"L7";

      mapping[59] = (char*)"R2";
      mapping[60] = (char*)"L6";

      mapping[61] = (char*)"R3";
      mapping[62] = (char*)"L5";
	  
	  mapping[63] = (char*)"R9";
      mapping[64] = (char*)"L2";

    }


    Commands Mapping::getCommands(char* key)
    {

      //Log.notice("Mapping.cpp getComand 55 input : %s \n", key);
      Commands commands;
      char* copy = strtrim_safe(key);
      if (strcmp((char*)key, "") != 0) {

        char prefixe = copy[0];

        switch (prefixe)
        {
          case 'W':  int nL, nR;
            ParseVectorString(copy, &nL, &nR);
            commands.leftSpeed = (float)nL / 100;
            commands.rightSpeed = (float)nR / 100;
            strcpy(commands.wheel, copy);
            Log.notice("Wheels - L=%d - R=%d \n", nL, nR);
            break;

          case 'N':
           // Log.notice("Neck - V=%d \n", val);
            strcpy(commands.neck, copy);
            break;

          case 'P':
            int piezzo;
            piezzo = GetIntAfterString(copy, "P");
            if (piezzo > 50)
              strcpy(commands.face, "F06");
            else if (piezzo > 35)
              strcpy(commands.face, "F05");
            else
              strcpy(commands.face, "F04");

          default :
            //Recherche dictionnaire (mapping)
            for (int i = 0; i < TABLE_SIZE - 1; i++) {
              if (strcmp(mapping[i], copy) == 0) {
                switch (mapping[i + 1][0]) {
                  case 'W':
                    strcpy(commands.wheel, mapping[i + 1]);
                    break;
                  case 'N':
                    strcpy(commands.neck, mapping[i + 1]);
                    //Log.notice("Light mapping command %s : mapping[i + 1]:%s commands.lights:%s\n", key, mapping[i + 1], commands.neck );
                    break;
                  case 'L':
                    strcpy(commands.lights, mapping[i + 1]);
                    //Log.notice("Light mapping command %s : mapping[i + 1]:%s commands.lights:%s\n", key, mapping[i + 1], commands.lights );
                    break;
                  case 'S':
                    strcpy(commands.sound, mapping[i + 1]);
                    break;
                  case 'F':
                    strcpy(commands.face, mapping[i + 1]);
                    break;
				  case 'R':
                    strcpy(commands.relays, mapping[i + 1]);
                    break;
                }
              }
            }
            break;

        }
      }
      return commands;
    }




    char* Mapping::getValue(char* key) {
      char* copy = strtrim_safe(key);
      if (strcmp((char*)key, "") != 0) {
        //Log.notice("copy %s\n", copy);
        //Log.notice("copy : %s\n", copy);
        for (int i = 0; i < TABLE_SIZE - 1; i++) {

#ifdef LOG_NOTICE_MAPPING
          Log.notice("mapping %d->%s\n", i, mapping[i]);
#endif

          if (strcmp(mapping[i], copy) == 0) {
            return mapping[i + 1];
          }
        }
      }
      return key;
    }
